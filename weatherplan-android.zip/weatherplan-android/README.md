# ☀️ WeatherPlan — Android App

A modern Android app that helps groups of friends chat, view a shared map, and vote on where to go out — all wrapped in a **live animated sky background** that reflects real cloud coverage at your location.

---

## ✨ Features

| Feature | Details |
|---|---|
| **Live Cloud Background** | Animated Compose Canvas sky that reacts in real time to `cloudCoverage %` from OpenWeatherMap — clear blue → scattered clouds → heavy overcast |
| **Group Chat** | Real-time-style chat with text bubbles + system weather alerts |
| **📍 Suggest a Place** | FAB in Chat opens a dialog; the pin appears instantly on the Map |
| **Shared Map** | Google Maps Compose with coloured markers for every suggested place |
| **Voting System** | Yes / No vote cards on both Chat and Map; live tallies per user |
| **Friends** | Friend list with online status, invite via link, add by username, accept/decline |
| **Profile** | Avatar colour picker, stats, activity feed, sign out |
| **Auth** | Login + Register screens with avatar colour selection |
| **Weather Dashboard** | 7-day forecast strip, go-out score, humidity, wind |

---

## 🏗️ Architecture

```
MVVM + Clean layering

┌─────────────────────────────────────────────┐
│                  UI Layer                   │
│  Jetpack Compose screens + ViewModels       │
│  CloudBackground · PlaceSuggestionCard      │
│  ChatScreen · MapScreen · FriendsScreen     │
│  ProfileScreen · HomeScreen · AuthScreens  │
└──────────────┬──────────────────────────────┘
               │ StateFlow / collectAsState
┌──────────────▼──────────────────────────────┐
│             Repository Layer                │
│  ChatRepository  — messages + places        │
│  WeatherRepository — OpenWeatherMap Retrofit│
│  FriendRepository — friends + invites       │
└──────────────┬──────────────────────────────┘
               │ suspend / Flow
┌──────────────▼──────────────────────────────┐
│              Data Layer                     │
│  WeatherApiService (Retrofit)               │
│  DTOs  →  domain Models                     │
│  AppContainer (manual DI)                   │
└─────────────────────────────────────────────┘
```

### Key design decisions

- **Shared `ChatRepository` singleton** — `ChatViewModel` and `MapViewModel` both read from the same `StateFlow<List<PlaceSuggestion>>`. A place suggested in chat appears on the map with zero latency, no event bus needed.
- **`CloudBackground` is a pure Composable** — it takes an `Int` (0–100) and drives all animations internally via `InfiniteTransition` + `animateColorAsState`. Drop it anywhere.
- **Manual DI via `AppContainer`** — no Hilt to keep setup friction low. Swap to `@HiltViewModel` by adding the Hilt plugin and replacing `AppContainer`.

---

## 📁 File Structure

```
app/src/main/java/com/weatherplan/app/
├── WeatherPlanApp.kt              # Application class
├── MainActivity.kt                # Single Activity entry point
├── di/
│   └── AppContainer.kt            # Manual DI — all singletons live here
├── data/
│   ├── api/
│   │   ├── NetworkClient.kt       # Retrofit + OkHttp setup
│   │   ├── WeatherApiService.kt   # API interface
│   │   └── dto/
│   │       └── WeatherResponse.kt # Gson DTOs
│   ├── model/
│   │   └── Models.kt              # User, Friend, ChatMessage, PlaceSuggestion, WeatherData
│   └── repository/
│       ├── WeatherRepository.kt
│       ├── ChatRepository.kt      # ← shared state for Chat + Map
│       └── FriendRepository.kt
└── ui/
    ├── theme/
    │   ├── Color.kt
    │   └── Theme.kt               # Material 3 + Typography
    ├── components/
    │   ├── CloudBackground.kt     # ⭐ Animated sky canvas
    │   └── CommonComponents.kt    # Avatar, WeatherBanner, PlaceCard, badges
    ├── navigation/
    │   └── NavGraph.kt            # Login → Main (tabbed) nav graph
    └── screens/
        ├── auth/    AuthScreens.kt   LoginScreen · RegisterScreen · AuthViewModel
        ├── home/    HomeScreen.kt    Dashboard with forecast + outing cards
        │            MainScreen.kt    Bottom-nav scaffold
        ├── chat/    ChatScreen.kt    Group chat + place suggestion FAB
        ├── map/     MapScreen.kt     Google Maps + voting sheet
        ├── friends/ FriendsScreen.kt Friends list + invite + pending requests
        └── profile/ ProfileScreen.kt Stats, activity, logout
```

---

## 🚀 Setup (5 minutes)

### 1 — Clone & open in Android Studio

```bash
git clone https://github.com/you/weatherplan-android.git
# Open the project root in Android Studio Hedgehog (or newer)
```

### 2 — Create `local.properties`

Copy the template and fill in your keys:

```bash
cp local.properties.template local.properties
```

Edit `local.properties`:
```properties
WEATHER_API_KEY=abc123...   # openweathermap.org → free tier
MAPS_API_KEY=AIzaSy...      # console.cloud.google.com → Maps SDK for Android
sdk.dir=/path/to/your/Android/sdk
```

### 3 — Build & Run

- Select a device (API 26+) and press ▶ Run
- On first launch, grant **Location** permission to enable live weather

> **No real API keys?** The app runs without keys — weather shows a placeholder state and the map renders without tiles. Location-based features degrade gracefully.

---

## 🔑 API Keys

| Service | Where to get it | Cost |
|---|---|---|
| OpenWeatherMap | [openweathermap.org/api](https://openweathermap.org/api) | Free (1000 calls/day) |
| Google Maps SDK | [console.cloud.google.com](https://console.cloud.google.com) | Free tier (~$200 credit/month) |

---

## 🛠️ Tech Stack

| Layer | Library | Version |
|---|---|---|
| Language | Kotlin | 2.0 |
| UI | Jetpack Compose + Material 3 | BOM 2024.12 |
| Architecture | MVVM + StateFlow | — |
| Navigation | Navigation Compose | 2.8 |
| Async | Coroutines + Flow | 1.9 |
| Networking | Retrofit 2 + Gson | 2.11 |
| Maps | Maps Compose | 6.2 |
| Location | Play Services Location | 21.3 |
| Permissions | Accompanist Permissions | 0.36 |
| Splash | SplashScreen Compat | 1.0 |

---

## 🗺️ Roadmap / Next Steps

- [ ] Firebase Auth (replace local login)
- [ ] Firestore real-time chat (replace in-memory ChatRepository)
- [ ] Google Places SDK autocomplete in Suggest dialog
- [ ] Push notifications when a friend votes
- [ ] Dark mode polish
- [ ] Widget showing today's go-out score

---

## 📄 License

MIT — free to use, fork, and build upon.
