# 📱 How to Get Your WeatherPlan APK

Three ways — pick the one that suits you.

---

## ✅ Option A — GitHub Actions (Recommended · No Android Studio needed)

**Time: ~5 minutes.  Cost: Free.**
GitHub's servers have the full Android SDK and build the APK for you automatically.

### Step 1 — Create a GitHub account (if you don't have one)
Go to **[github.com/signup](https://github.com/signup)** — it's free.

---

### Step 2 — Create a new repository

1. Click the **+** button → **New repository**
2. Name it `weatherplan-android`
3. Set it to **Public** (or Private — both work)
4. Click **Create repository**

---

### Step 3 — Upload the project files

In your new empty repository, click **"uploading an existing file"**:

```
Upload ALL files from the zip you downloaded, keeping the folder structure.
The root of the repo should contain:
  app/
  gradle/
  .github/
  build.gradle.kts
  settings.gradle.kts
  gradlew
  gradlew.bat
  README.md
  ...
```

Or use Git from your terminal:

```bash
# Unzip the downloaded file
unzip weatherplan-android.zip
cd weatherplan-android

# Initialize and push
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/weatherplan-android.git
git push -u origin main
```

---

### Step 4 — Watch the build run automatically

After you push:

1. Click the **Actions** tab at the top of your repo
2. You will see **"🏗️ Build WeatherPlan APK"** running (yellow spinner)
3. Wait **3–7 minutes** for it to finish (green ✅)

---

### Step 5 — Download your APK

1. Click on the completed workflow run
2. Scroll to the bottom — you'll see **Artifacts**
3. Click **WeatherPlan-APK-build-1** to download a `.zip`
4. Unzip it → you get **`WeatherPlan-debug-1.apk`**

---

### Step 6 — Install on your Android phone

1. Copy the APK to your phone (USB, email, Google Drive, etc.)
2. On your phone: **Settings → Security → Install from Unknown Sources** → Enable
3. Open the APK file with **File Manager** → tap **Install**
4. Launch **WeatherPlan** 🎉

> ⚠️ The demo APK uses placeholder API keys. The UI, chat, maps, and friends
> features all work, but weather will show an error state and map tiles will be
> grey until you add real keys (see Step 7 below).

---

### Step 7 (Optional) — Add your real API keys for live weather + map tiles

1. Get a **free OpenWeatherMap key** at [openweathermap.org/api](https://openweathermap.org/api)
2. Get a **Google Maps key** at [console.cloud.google.com](https://console.cloud.google.com)
   → Enable: *Maps SDK for Android* + *Places API*
3. In your GitHub repo → **Settings → Secrets and variables → Actions**
4. Add two secrets:
   - `WEATHER_API_KEY` = your OpenWeatherMap key
   - `MAPS_API_KEY`    = your Google Maps key
5. Go to **Actions** → click **Run workflow** → new build generates a live-data APK

---

## 🛠️ Option B — Android Studio (local build)

**Time: ~15 minutes.  Requires: Android Studio installed.**

1. Download and install **[Android Studio](https://developer.android.com/studio)** (free)
2. Unzip `weatherplan-android.zip`
3. In Android Studio: **File → Open** → select the `weatherplan-android` folder
4. Copy `local.properties.template` → `local.properties` and fill in your keys
5. Wait for Gradle sync to finish (first time downloads ~500 MB)
6. Click **Build → Build Bundle(s) / APK(s) → Build APK(s)**
7. APK will be at: `app/build/outputs/apk/debug/app-debug.apk`

---

## ☁️ Option C — Codemagic (alternative cloud build, no GitHub required)

**Time: ~10 minutes.  Cost: Free tier (500 build minutes/month).**

1. Go to **[codemagic.io](https://codemagic.io)** → sign up
2. Click **Add application** → upload your project ZIP
3. The included `codemagic.yaml` configures the build automatically
4. Click **Start build**
5. Download the APK from the build results
6. Codemagic can also email the APK directly to you

---

## 🔍 Troubleshooting

| Problem | Fix |
|---|---|
| Build fails with `SDK not found` | Check that `ANDROID_SDK_ROOT` is set in the Action log |
| `Execution failed for task ':app:compileDebugKotlin'` | Check for a typo in a Kotlin file — open the log and search for `error:` |
| APK installs but crashes immediately | Missing Maps API key — add it in GitHub Secrets and rebuild |
| `INSTALL_FAILED_UPDATE_INCOMPATIBLE` | Uninstall the old version first, then install the new APK |
| Google Maps shows grey tiles | Add `MAPS_API_KEY` secret and rebuild |
| Weather always shows "Network error" | Add `WEATHER_API_KEY` secret and rebuild |

---

## 📋 Minimum Android requirements

| Requirement | Value |
|---|---|
| **Android version** | Android 8.0 (API 26) or higher |
| **RAM** | 2 GB+ recommended |
| **Storage** | ~50 MB |
| **GPS / Location** | Required for live weather at your location |
| **Internet** | Required for weather data and map tiles |

---

## 🔐 About the debug APK

The APK built by GitHub Actions is a **debug** build:
- ✅ Fully functional — all features work
- ✅ Auto-signed with a debug keystore — installs on any unlocked device
- ⚠️ Cannot be published to the Google Play Store (needs a release keystore)
- ⚠️ Shows `debuggable=true` — fine for personal use

To generate a **release APK** for Play Store, add a keystore to GitHub Secrets and
update `app/build.gradle.kts` with a `signingConfigs` block — the README has details.
