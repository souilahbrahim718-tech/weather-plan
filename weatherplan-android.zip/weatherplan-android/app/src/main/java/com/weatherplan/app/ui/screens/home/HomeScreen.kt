package com.weatherplan.app.ui.screens.home

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.google.android.gms.location.LocationServices
import com.weatherplan.app.data.model.PlaceSuggestion
import com.weatherplan.app.data.model.WeatherCondition
import com.weatherplan.app.data.model.WeatherData
import com.weatherplan.app.ui.components.*
import com.weatherplan.app.ui.navigation.Screen
import com.weatherplan.app.ui.screens.chat.ChatViewModel
import com.weatherplan.app.ui.theme.*
import kotlinx.coroutines.tasks.await

// Forecast day model (7-day strip)
private data class ForecastDay(
    val dayLabel: String,
    val emoji: String,
    val tempC: Int,
    val cloudPct: Int,
    val isToday: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    chatViewModel: ChatViewModel,
    navController: NavController
) {
    val weather  by chatViewModel.weather.collectAsStateWithLifecycle()
    val places   by chatViewModel.places.collectAsStateWithLifecycle()
    val context  = LocalContext.current

    // Fetch real weather on first load
    LaunchedEffect(Unit) {
        try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val loc    = client.lastLocation.await()
            if (loc != null) chatViewModel.loadWeather(loc.latitude, loc.longitude)
            else             chatViewModel.loadWeather(36.806, 10.181)
        } catch (_: Exception) {
            chatViewModel.loadWeather(36.806, 10.181)
        }
    }

    // Demo 7-day forecast (replace with multi-day API call in production)
    val forecast = remember {
        listOf(
            ForecastDay("Today", weatherEmoji(weather.cloudCoverage), weather.temperature.toInt(),
                        weather.cloudCoverage, isToday = true),
            ForecastDay("Tue", "⛅", 21, 35),
            ForecastDay("Wed", "🌧️", 17, 80),
            ForecastDay("Thu", "⛈️", 15, 90),
            ForecastDay("Fri", "🌤️", 22, 40),
            ForecastDay("Sat", "☀️", 26, 10),
            ForecastDay("Sun", "☀️", 27, 5),
        )
    }

    // Full-screen cloud background
    CloudBackground(
        cloudCoverage = weather.cloudCoverage,
        modifier      = Modifier.fillMaxSize()
    ) {
        LazyColumn(
            contentPadding      = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(0.dp),
            modifier            = Modifier.fillMaxSize()
        ) {

            // ── Top header ──────────────────────────────────────────────────
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp)
                        .padding(top = 56.dp, bottom = 16.dp)
                ) {
                    Row(
                        verticalAlignment    = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier            = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text(
                                text = greetingFor(chatViewModel.currentUser.name),
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                            Text(
                                chatViewModel.currentUser.name,
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                        Avatar(
                            letter   = chatViewModel.currentUser.avatarLetter,
                            color    = chatViewModel.currentUser.avatarColor,
                            size     = 42.dp
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    // Weather banner
                    if (weather.isLoading) {
                        LinearProgressIndicator(
                            color    = Color.White,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        WeatherHeaderBanner(
                            weather  = weather,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // ── Go-Out score card ───────────────────────────────────────────
            item {
                Surface(
                    shape    = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                    color    = Background,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 20.dp)
                    ) {
                        GoOutScoreCard(weather)
                    }
                }
            }

            // ── 7-day forecast strip ────────────────────────────────────────
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Background)
                        .padding(horizontal = 16.dp)
                ) {
                    SectionHeader("7-Day Forecast")
                    LazyRow(
                        contentPadding      = PaddingValues(bottom = 8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(forecast) { day ->
                            ForecastDayChip(day)
                        }
                    }
                }
            }

            // ── Suggested outings ───────────────────────────────────────────
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Background)
                        .padding(horizontal = 16.dp)
                ) {
                    SectionHeader(
                        title = "Planned Outings",
                        actionLabel = "+ New",
                        onAction    = { navController.navigate(Screen.Chat.route) }
                    )
                }
            }

            if (places.isEmpty()) {
                item {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Background)
                            .padding(horizontal = 16.dp, vertical = 32.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("🗺️", fontSize = 40.sp)
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "No outings yet",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                "Go to Chat and suggest a place\nto plan a trip with friends!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextMuted
                            )
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick = { navController.navigate(Screen.Chat.route) },
                                colors  = ButtonDefaults.buttonColors(containerColor = SkyBlue),
                                shape   = RoundedCornerShape(12.dp)
                            ) { Text("Open Chat") }
                        }
                    }
                }
            } else {
                items(places, key = { it.id }) { place ->
                    OutingCard(
                        place        = place,
                        weather      = weather,
                        currentUserId = chatViewModel.currentUser.id,
                        onVoteYes    = { chatViewModel.vote(place.id, true) },
                        onVoteNo     = { chatViewModel.vote(place.id, false) },
                        onOpenMap    = { navController.navigate(Screen.Map.route) },
                        modifier     = Modifier
                            .fillMaxWidth()
                            .background(Background)
                            .padding(horizontal = 16.dp)
                            .padding(bottom = 10.dp)
                    )
                }
            }

            // Bottom spacer inside background surface
            item {
                Spacer(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .background(Background)
                )
            }
        }
    }
}

// ─────────────────────────────────────────────
// Go-Out Score Card
// ─────────────────────────────────────────────

@Composable
private fun GoOutScoreCard(weather: WeatherData) {
    val (bgColor, fgColor) = when {
        weather.goOutScore >= 75 -> GreenGoLight to Color(0xFF0A7A50)
        weather.goOutScore >= 50 -> AmberMaybeLight to Color(0xFFA06010)
        else                     -> RedNoLight to RedNo
    }
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = bgColor
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp)
        ) {
            Text(
                when {
                    weather.goOutScore >= 75 -> "🌟"
                    weather.goOutScore >= 50 -> "👍"
                    else                     -> "🏠"
                },
                fontSize = 32.sp
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    weather.goOutLabel,
                    fontWeight = FontWeight.Bold,
                    fontSize   = 15.sp,
                    color      = fgColor
                )
                Text(
                    "Cloud cover ${weather.cloudCoverage}% · ${weather.temperature.toInt()}°C · Humidity ${weather.humidity}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = fgColor.copy(alpha = 0.75f)
                )
            }
            GoOutScoreChip(weather.goOutScore)
        }
    }
}

// ─────────────────────────────────────────────
// Forecast Day Chip
// ─────────────────────────────────────────────

@Composable
private fun ForecastDayChip(day: ForecastDay) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (day.isToday) SkyBlue else Color.White,
        shadowElevation = if (day.isToday) 4.dp else 1.dp
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)
        ) {
            Text(
                day.dayLabel,
                style    = MaterialTheme.typography.labelSmall,
                color    = if (day.isToday) Color.White.copy(0.85f) else TextMuted
            )
            Spacer(Modifier.height(4.dp))
            Text(day.emoji, fontSize = 20.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "${day.tempC}°",
                style      = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color      = if (day.isToday) Color.White else TextPrimary
            )
            Spacer(Modifier.height(2.dp))
            // Good / Bad badge
            Text(
                text  = if (day.cloudPct < 50) "OK" else "Rain",
                style = MaterialTheme.typography.labelSmall,
                color = if (day.isToday) Color.White.copy(0.8f)
                        else if (day.cloudPct < 50) Color(0xFF0A7A50) else RedNo,
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        when {
                            day.isToday        -> Color.White.copy(0.2f)
                            day.cloudPct < 50  -> GreenGoLight
                            else               -> RedNoLight
                        }
                    )
                    .padding(horizontal = 5.dp, vertical = 2.dp)
            )
        }
    }
}

// ─────────────────────────────────────────────
// Outing Card
// ─────────────────────────────────────────────

@Composable
private fun OutingCard(
    place:         PlaceSuggestion,
    weather:       WeatherData,
    currentUserId: String,
    onVoteYes:     () -> Unit,
    onVoteNo:      () -> Unit,
    onOpenMap:     () -> Unit,
    modifier:      Modifier = Modifier
) {
    Surface(
        shape           = RoundedCornerShape(16.dp),
        color           = Color.White,
        shadowElevation = 3.dp,
        modifier        = modifier
    ) {
        Column(Modifier.padding(14.dp)) {
            // Header row
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(place.weatherSuitability.emoji, fontSize = 26.sp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        place.name,
                        style      = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (place.address.isNotBlank())
                        Text(
                            place.address,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                            maxLines = 1
                        )
                    Text(
                        "${weatherEmoji(weather.cloudCoverage)} ${weather.temperature.toInt()}°C · ${weather.description}",
                        style = MaterialTheme.typography.labelSmall,
                        color = SkyBlue
                    )
                }
                // Suggested by
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Avatar(
                        letter = place.suggestedByName.first().uppercase(),
                        color  = 0xFF2A7FE8,
                        size   = 28.dp
                    )
                    Text(
                        "by ${place.suggestedByName.split(" ").first()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Vote summary
            Text(
                "✅ ${place.yesCount} going  ❌ ${place.noCount} can't  👥 ${place.totalVotes} total",
                style = MaterialTheme.typography.labelMedium,
                color = TextMuted
            )

            Spacer(Modifier.height(8.dp))

            // Vote row
            val userVote = place.votes[currentUserId]
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick  = onVoteYes,
                    shape    = RoundedCornerShape(10.dp),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (userVote == true) GreenGoLight else Color.Transparent,
                        contentColor   = if (userVote == true) GreenGo else TextMuted
                    ),
                    border  = androidx.compose.foundation.BorderStroke(
                        1.dp, if (userVote == true) GreenGo else Border
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text("✓ I'm in", style = MaterialTheme.typography.labelLarge) }

                OutlinedButton(
                    onClick  = onVoteNo,
                    shape    = RoundedCornerShape(10.dp),
                    colors   = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (userVote == false) RedNoLight else Color.Transparent,
                        contentColor   = if (userVote == false) RedNo else TextMuted
                    ),
                    border  = androidx.compose.foundation.BorderStroke(
                        1.dp, if (userVote == false) RedNo else Border
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text("✗ Can't go", style = MaterialTheme.typography.labelLarge) }

                OutlinedButton(
                    onClick  = onOpenMap,
                    shape    = RoundedCornerShape(10.dp),
                    colors   = ButtonDefaults.outlinedButtonColors(contentColor = SkyBlue),
                    border   = androidx.compose.foundation.BorderStroke(1.dp, SkyBluePale),
                    modifier = Modifier.width(56.dp)
                ) { Icon(Icons.Default.Map, null, modifier = Modifier.size(18.dp)) }
            }
        }
    }
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

@Composable
private fun SectionHeader(
    title:       String,
    actionLabel: String? = null,
    onAction:    (() -> Unit)? = null
) {
    Row(
        verticalAlignment    = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier             = Modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp, top = 4.dp)
    ) {
        Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (actionLabel != null && onAction != null) {
            TextButton(onClick = onAction, contentPadding = PaddingValues(0.dp)) {
                Text(actionLabel, style = MaterialTheme.typography.labelMedium, color = SkyBlue)
            }
        }
    }
}

private fun greetingFor(name: String): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val base = when {
        hour < 12 -> "Good morning"
        hour < 17 -> "Good afternoon"
        else      -> "Good evening"
    }
    return "$base 👋"
}

private fun String.first() = this[0]
