package com.weatherplan.app.ui.screens.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavController
import com.weatherplan.app.data.model.*
import com.weatherplan.app.data.repository.ChatRepository
import com.weatherplan.app.data.repository.WeatherRepository
import com.weatherplan.app.ui.components.*
import com.weatherplan.app.ui.navigation.Screen
import com.weatherplan.app.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

// ─────────────────────────────────────────────
// ViewModel
// ─────────────────────────────────────────────

class ChatViewModel(
    private val chatRepo:    ChatRepository,
    private val weatherRepo: WeatherRepository
) : ViewModel() {

    val messages = chatRepo.messages
    val places   = chatRepo.places

    // Live weather state — shared with HomeScreen via the same ViewModel instance
    val weather = MutableStateFlow(WeatherData(isLoading = true))

    fun loadWeather(lat: Double, lon: Double) {
        viewModelScope.launch {
            weatherRepo.getWeather(lat, lon).collect { weather.value = it }
        }
    }

    // Simulated current user (in real app, comes from AuthViewModel / session)
    val currentUser = User(
        id = "me", name = "Ahmed Ben Ali",
        username = "@ahmed_tunis", avatarColor = 0xFF2A7FE8
    )

    fun send(text: String) {
        if (text.isBlank()) return
        chatRepo.sendMessage(
            ChatMessage(
                senderId          = currentUser.id,
                senderName        = currentUser.name,
                senderAvatarColor = currentUser.avatarColor,
                content           = text
            )
        )
    }

    fun suggestPlace(name: String, address: String, lat: Double, lon: Double) {
        val place = PlaceSuggestion(
            name            = name,
            address         = address,
            latitude        = lat,
            longitude       = lon,
            suggestedById   = currentUser.id,
            suggestedByName = currentUser.name
        )
        chatRepo.sendMessage(
            ChatMessage(
                senderId          = currentUser.id,
                senderName        = currentUser.name,
                senderAvatarColor = currentUser.avatarColor,
                content           = "📍 I suggest: $name",
                type              = MessageType.PLACE_SUGGESTION,
                placeSuggestion   = place
            )
        )
    }

    fun vote(placeId: String, yes: Boolean) =
        chatRepo.voteOnPlace(placeId, currentUser.id, yes)

    fun updateCurrentUser(user: User) {
        // In a real app this would update a backing UserRepository.
        // Here we just keep a local reference so the chat reflects the chosen name/avatar.
        _currentUserState.value = user
    }

    private val _currentUserState = MutableStateFlow(currentUser)
}

class ChatViewModelFactory(
    private val chatRepo:    ChatRepository,
    private val weatherRepo: WeatherRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(c: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return ChatViewModel(chatRepo, weatherRepo) as T
    }
}

// ─────────────────────────────────────────────
// Chat Screen
// ─────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel:     ChatViewModel,
    navController: NavController
) {
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()
    val scope     = rememberCoroutineScope()

    var inputText   by remember { mutableStateOf("") }
    var showSuggest by remember { mutableStateOf(false) }

    // Auto-scroll to bottom on new message
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Group Chat", fontWeight = FontWeight.Bold)
                        Text("4 friends online", style = MaterialTheme.typography.labelSmall,
                             color = GreenGo)
                    }
                },
                navigationIcon = {
                    IconButton({ navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SkyBlue,
                    titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick           = { showSuggest = true },
                icon              = { Icon(Icons.Default.AddLocation, null) },
                text              = { Text("Suggest a Place") },
                containerColor    = SkyBlue,
                contentColor      = Color.White
            )
        },
        bottomBar = {
            Surface(shadowElevation = 8.dp) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value          = inputText,
                        onValueChange  = { inputText = it },
                        placeholder    = { Text("Message…") },
                        shape          = RoundedCornerShape(24.dp),
                        singleLine     = true,
                        modifier       = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        onClick  = {
                            viewModel.send(inputText.trim())
                            inputText = ""
                            scope.launch { if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1) }
                        },
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(SkyBlue)
                    ) { Icon(Icons.Default.Send, null, tint = Color.White) }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state           = listState,
            contentPadding  = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier        = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            items(messages, key = { it.id }) { msg ->
                MessageItem(
                    message      = msg,
                    isOwn        = msg.senderId == viewModel.currentUser.id,
                    currentUserId = viewModel.currentUser.id,
                    onVoteYes    = { msg.placeSuggestion?.let { viewModel.vote(it.id, true) } },
                    onVoteNo     = { msg.placeSuggestion?.let { viewModel.vote(it.id, false) } },
                    onOpenMap    = { navController.navigate(Screen.Map.route) }
                )
            }
        }
    }

    if (showSuggest) {
        SuggestPlaceDialog(
            onDismiss = { showSuggest = false },
            onConfirm = { name, address, lat, lon ->
                viewModel.suggestPlace(name, address, lat, lon)
                showSuggest = false
            }
        )
    }
}

// ─────────────────────────────────────────────
// Message bubble
// ─────────────────────────────────────────────

@Composable
private fun MessageItem(
    message:       ChatMessage,
    isOwn:         Boolean,
    currentUserId: String,
    onVoteYes:     () -> Unit,
    onVoteNo:      () -> Unit,
    onOpenMap:     () -> Unit
) {
    when (message.type) {
        MessageType.SYSTEM -> SystemMessage(message.content)

        MessageType.PLACE_SUGGESTION -> {
            Column(modifier = Modifier.fillMaxWidth()) {
                BubbleHeader(message, isOwn)
                Spacer(Modifier.height(4.dp))
                message.placeSuggestion?.let { place ->
                    PlaceSuggestionCard(
                        place         = place,
                        currentUserId = currentUserId,
                        onVoteYes     = onVoteYes,
                        onVoteNo      = onVoteNo,
                        modifier      = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(4.dp))
                    TextButton(onClick = onOpenMap) {
                        Text("View on Map →", color = SkyBlue,
                             style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        MessageType.TEXT -> {
            Row(
                modifier              = Modifier.fillMaxWidth(),
                horizontalArrangement = if (isOwn) Arrangement.End else Arrangement.Start
            ) {
                if (!isOwn) {
                    Avatar(message.senderName.first().uppercase(), message.senderAvatarColor,
                           size = 32.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Column(horizontalAlignment = if (isOwn) Alignment.End else Alignment.Start) {
                    if (!isOwn) Text(message.senderName,
                                     style = MaterialTheme.typography.labelSmall,
                                     color = TextMuted,
                                     modifier = Modifier.padding(bottom = 2.dp))
                    Box(
                        modifier = Modifier
                            .clip(
                                RoundedCornerShape(
                                    topStart = if (isOwn) 16.dp else 4.dp,
                                    topEnd   = if (isOwn) 4.dp  else 16.dp,
                                    bottomStart = 16.dp, bottomEnd = 16.dp
                                )
                            )
                            .background(if (isOwn) SkyBlue else Color.White)
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text  = message.content,
                            color = if (isOwn) Color.White else TextPrimary,
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    Text(
                        text  = formatTime(message.timestamp),
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        modifier = Modifier.padding(top = 2.dp, start = 4.dp, end = 4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun BubbleHeader(msg: ChatMessage, isOwn: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Avatar(msg.senderName.first().uppercase(), msg.senderAvatarColor, size = 28.dp)
        Spacer(Modifier.width(6.dp))
        Text(msg.senderName, style = MaterialTheme.typography.labelMedium, color = TextMuted)
    }
}

@Composable
private fun SystemMessage(text: String) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text  = text,
            style = MaterialTheme.typography.labelMedium,
            color = TextMuted,
            modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .background(SkyBlueLight)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

// ─────────────────────────────────────────────
// Suggest Place Dialog
// ─────────────────────────────────────────────

@Composable
private fun SuggestPlaceDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, address: String, lat: Double, lon: Double) -> Unit
) {
    var name    by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    // Demo coordinates for Tunis area; in production use Places SDK autocomplete
    val presets = listOf(
        Triple("La Goulette Beach",     "La Goulette, Tunis",       Pair(36.818, 10.305)),
        Triple("Parc du Belvédère",     "Belvédère, Tunis",         Pair(36.825, 10.183)),
        Triple("Musée du Bardo",        "Le Bardo, Tunis",          Pair(36.809, 10.134)),
        Triple("Café Saf Saf",          "Medina, Tunis",            Pair(36.799, 10.170)),
        Triple("Site de Carthage",      "Carthage, Tunis",          Pair(36.858, 10.323)),
    )
    var selectedPreset by remember { mutableStateOf(-1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("📍 Suggest a Place", fontWeight = FontWeight.Bold) },
        text  = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Quick pick:", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                presets.forEachIndexed { i, (pName, pAddr, _) ->
                    FilterChip(
                        selected = selectedPreset == i,
                        onClick  = {
                            selectedPreset = i
                            name    = pName
                            address = pAddr
                        },
                        label    = { Text(pName) }
                    )
                }
                Divider()
                OutlinedTextField(value = name, onValueChange = { name = it; selectedPreset = -1 },
                    label = { Text("Place name") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp))
                OutlinedTextField(value = address, onValueChange = { address = it },
                    label = { Text("Address / notes") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp))
            }
        },
        confirmButton = {
            Button(onClick = {
                val (lat, lon) = if (selectedPreset >= 0) presets[selectedPreset].third
                                 else Pair(36.806, 10.181) // default Tunis centre
                onConfirm(name, address, lat, lon)
            }, enabled = name.isNotBlank()) { Text("Suggest") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

// ─────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────

private val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
private fun formatTime(ts: Long) = timeFmt.format(Date(ts))

// Missing import alias
private fun String.first() = this[0]
private val CircleShape = RoundedCornerShape(50)
