package com.weatherplan.app.ui.screens.friends

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.weatherplan.app.data.model.Friend
import com.weatherplan.app.data.model.VoteStatus
import com.weatherplan.app.data.repository.FriendRepository
import com.weatherplan.app.ui.components.Avatar
import com.weatherplan.app.ui.components.OnlineDot
import com.weatherplan.app.ui.theme.*
import kotlinx.coroutines.launch

// ─────────────────────────────────────────────
// ViewModel
// ─────────────────────────────────────────────

class FriendsViewModel(private val repo: FriendRepository) : ViewModel() {
    val friends       = repo.friends
    val pendingInvites = repo.pendingInvites

    fun accept(id: String)  = repo.acceptInvite(id)
    fun decline(id: String) = repo.declineInvite(id)
    fun remove(id: String)  = repo.removeFriend(id)

    fun sendInvite(username: String): Boolean = repo.sendInvite(username)
    fun inviteLink(userId: String) = repo.generateInviteLink(userId)
}

class FriendsViewModelFactory(private val repo: FriendRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(c: Class<T>): T {
        @Suppress("UNCHECKED_CAST") return FriendsViewModel(repo) as T
    }
}

// ─────────────────────────────────────────────
// Screen
// ─────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FriendsScreen(
    viewModel:     FriendsViewModel,
    currentUserId: String,
    navController: NavController
) {
    val friends        by viewModel.friends.collectAsStateWithLifecycle()
    val pendingInvites by viewModel.pendingInvites.collectAsStateWithLifecycle()
    val clipboard      = LocalClipboardManager.current

    var showInviteSheet by remember { mutableStateOf(false) }
    var usernameInput  by remember { mutableStateOf("") }
    var inviteSent     by remember { mutableStateOf(false) }
    var snackMessage   by remember { mutableStateOf("") }
    val snackState     = remember { SnackbarHostState() }
    val scope          = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Friends", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = SkyBlue, titleContentColor = Color.White)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick        = { showInviteSheet = true },
                icon           = { Icon(Icons.Default.PersonAdd, null) },
                text           = { Text("Invite Friend") },
                containerColor = SkyBlue,
                contentColor   = Color.White
            )
        },
        snackbarHost = { SnackbarHost(snackState) }
    ) { padding ->

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {

            // ── Invite link banner ──────────────────────────────────────────
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = SkyBlue
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Invite via link", fontWeight = FontWeight.Bold,
                             color = Color.White, fontSize = 16.sp)
                        Text("Share your personal link with friends",
                             style = MaterialTheme.typography.bodyMedium,
                             color = Color.White.copy(0.85f))
                        Spacer(Modifier.height(10.dp))
                        Surface(
                            shape  = RoundedCornerShape(10.dp),
                            color  = Color.White.copy(0.2f),
                            onClick = {
                                val link = viewModel.inviteLink(currentUserId)
                                clipboard.setText(AnnotatedString(link))
                                scope.launch { snackState.showSnackbar("Link copied!") }
                            }
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            ) {
                                Text(
                                    viewModel.inviteLink(currentUserId),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = Color.White,
                                    modifier = Modifier.weight(1f),
                                    maxLines = 1
                                )
                                Icon(Icons.Default.ContentCopy, null,
                                     tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            // ── Pending invites ─────────────────────────────────────────────
            if (pendingInvites.isNotEmpty()) {
                item {
                    Text("Pending Requests (${pendingInvites.size})",
                         style = MaterialTheme.typography.titleMedium,
                         modifier = Modifier.padding(top = 8.dp))
                }
                items(pendingInvites, key = { it.id }) { friend ->
                    PendingInviteRow(
                        friend    = friend,
                        onAccept  = { viewModel.accept(friend.id) },
                        onDecline = { viewModel.decline(friend.id) }
                    )
                }
                item { Divider(modifier = Modifier.padding(vertical = 4.dp)) }
            }

            // ── Friend list ─────────────────────────────────────────────────
            item {
                Text("My Friends (${friends.size})", style = MaterialTheme.typography.titleMedium)
            }
            if (friends.isEmpty()) {
                item {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(40.dp)
                    ) {
                        Text("No friends yet.\nTap \"Invite Friend\" to get started!",
                             style = MaterialTheme.typography.bodyMedium,
                             color = TextMuted)
                    }
                }
            } else {
                items(friends, key = { it.id }) { friend ->
                    FriendRow(
                        friend   = friend,
                        onRemove = { viewModel.remove(friend.id) }
                    )
                }
            }
        }
    }

    // ── Invite-by-username bottom sheet ──────────────────────────────────────
    if (showInviteSheet) {
        ModalBottomSheet(onDismissRequest = { showInviteSheet = false }) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .padding(bottom = 40.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("Add a friend", style = MaterialTheme.typography.titleLarge)
                Text("Enter their username to send an invite",
                     style = MaterialTheme.typography.bodyMedium, color = TextMuted)

                OutlinedTextField(
                    value         = usernameInput,
                    onValueChange = { usernameInput = it; inviteSent = false },
                    label         = { Text("Username") },
                    prefix        = { Text("@") },
                    singleLine    = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    shape         = RoundedCornerShape(12.dp),
                    modifier      = Modifier.fillMaxWidth()
                )

                if (inviteSent) {
                    Text("✅ Invite sent to @$usernameInput!",
                         color = GreenGo, fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        if (viewModel.sendInvite(usernameInput)) {
                            inviteSent = true
                        }
                    },
                    enabled  = usernameInput.isNotBlank() && !inviteSent,
                    shape    = RoundedCornerShape(14.dp),
                    colors   = ButtonDefaults.buttonColors(containerColor = SkyBlue),
                    modifier = Modifier.fillMaxWidth().height(50.dp)
                ) { Text("Send Invite", fontWeight = FontWeight.Bold) }

                TextButton(
                    onClick  = { showInviteSheet = false },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Cancel") }
            }
        }
    }
}

// ─────────────────────────────────────────────
// Row components
// ─────────────────────────────────────────────

@Composable
private fun FriendRow(friend: Friend, onRemove: () -> Unit) {
    var showMenu by remember { mutableStateOf(false) }

    Surface(
        shape  = RoundedCornerShape(14.dp),
        color  = Color.White,
        shadowElevation = 2.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Box {
                Avatar(friend.avatarLetter, friend.avatarColor)
                OnlineDot(
                    friend.isOnline,
                    modifier = Modifier.align(Alignment.BottomEnd).offset(2.dp, 2.dp)
                )
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(friend.name, style = MaterialTheme.typography.titleMedium)
                Text(friend.username, style = MaterialTheme.typography.bodyMedium, color = TextMuted)
                Text(
                    when (friend.isOnline) { true -> "🟢 Online" else -> "⚪ Offline" },
                    style = MaterialTheme.typography.labelSmall, color = TextMuted
                )
            }
            // Vote badge
            Text(
                text = when (friend.voteStatus) {
                    VoteStatus.YES     -> "✅"
                    VoteStatus.NO      -> "❌"
                    VoteStatus.MAYBE   -> "🤔"
                    VoteStatus.PENDING -> "⏳"
                },
                fontSize = 20.sp
            )
            Spacer(Modifier.width(8.dp))
            Box {
                IconButton({ showMenu = true }) { Icon(Icons.Default.MoreVert, null) }
                DropdownMenu(showMenu, { showMenu = false }) {
                    DropdownMenuItem(
                        text    = { Text("Remove friend", color = RedNo) },
                        onClick = { onRemove(); showMenu = false },
                        leadingIcon = { Icon(Icons.Default.PersonRemove, null, tint = RedNo) }
                    )
                }
            }
        }
    }
}

@Composable
private fun PendingInviteRow(friend: Friend, onAccept: () -> Unit, onDecline: () -> Unit) {
    Surface(
        shape  = RoundedCornerShape(14.dp),
        color  = AmberMaybeLight,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Avatar(friend.avatarLetter, friend.avatarColor)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(friend.name, style = MaterialTheme.typography.titleMedium)
                Text("Wants to be friends", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
            }
            IconButton(onAccept) {
                Icon(Icons.Default.Check, null, tint = GreenGo)
            }
            IconButton(onDecline) {
                Icon(Icons.Default.Close, null, tint = RedNo)
            }
        }
    }
}
