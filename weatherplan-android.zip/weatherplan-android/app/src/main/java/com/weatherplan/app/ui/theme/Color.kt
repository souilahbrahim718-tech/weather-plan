package com.weatherplan.app.ui.theme

import androidx.compose.ui.graphics.Color

// ── Brand ──────────────────────────────────────────────────────────────────
val SkyBlue        = Color(0xFF2A7FE8)
val SkyBlueDark    = Color(0xFF1456A8)
val SkyBlueLight   = Color(0xFFEBF4FF)
val SkyBluePale    = Color(0xFFD6EAFF)

// ── Semantic ────────────────────────────────────────────────────────────────
val GreenGo        = Color(0xFF2DC98A)
val GreenGoLight   = Color(0xFFE3FBF1)
val AmberMaybe     = Color(0xFFF5A623)
val AmberMaybeLight= Color(0xFFFFF4E0)
val RedNo          = Color(0xFFF04444)
val RedNoLight     = Color(0xFFFDEAEA)

// ── Neutrals ────────────────────────────────────────────────────────────────
val TextPrimary    = Color(0xFF1A1A2E)
val TextMuted      = Color(0xFF7A7A9A)
val Surface        = Color(0xFFFFFFFF)
val Background     = Color(0xFFF4F7FB)
val Border         = Color(0x14000000)   // 8% black

// ── Avatar palette (used for friend avatars) ────────────────────────────────
val AvatarColors = listOf(
    Color(0xFF2A7FE8), Color(0xFF2DC98A), Color(0xFFE056A0),
    Color(0xFFF5A623), Color(0xFF9B59B6), Color(0xFF1ABC9C),
    Color(0xFF3498DB), Color(0xFFE74C3C)
)

// ── Weather sky colors ──────────────────────────────────────────────────────
val ClearSkyTop      = Color(0xFF0D47A1)
val ClearSkyBottom   = Color(0xFF42A5F5)
val PartlyCloudyTop  = Color(0xFF1565C0)
val PartlyCloudyBot  = Color(0xFF64B5F6)
val CloudyTop        = Color(0xFF455A64)
val CloudyBot        = Color(0xFF78909C)
val OvercastTop      = Color(0xFF37474F)
val OvercastBot      = Color(0xFF546E7A)
