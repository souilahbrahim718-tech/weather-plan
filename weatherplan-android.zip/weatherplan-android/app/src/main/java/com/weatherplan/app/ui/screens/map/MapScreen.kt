package com.weatherplan.app.ui.screens.map

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavController
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.*
import com.google.maps.android.compose.*
import com.weatherplan.app.data.model.*
import com.weatherplan.app.data.repository.ChatRepository
import com.weatherplan.app.data.repository.WeatherRepository
import com.weatherplan.app.ui.components.*
import com.weatherplan.app.ui.theme.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

// ─────────────────────────────────────────────
// ViewModel
// ─────────────────────────────────────────────

class MapViewModel(
    private val chatRepo:    ChatRepository,
    private val weatherRepo: WeatherRepository
) : ViewModel() {

    val places  = chatRepo.places
    val weather = MutableStateFlow(WeatherData(isLoading = true))

    private val _selectedPlace = MutableStateFlow<PlaceSuggestion?>(null)
    val selectedPlace: StateFlow<PlaceSuggestion?> = _selectedPlace.asStateFlow()

    // Default: Tunis centre
    private val _mapCenter = MutableStateFlow(LatLng(36.806, 10.181))
    val mapCenter: StateFlow<LatLng> = _mapCenter.asStateFlow()

    fun selectPlace(place: PlaceSuggestion?) { _selectedPlace.value = place }

    fun vote(placeId: String, userId: String, yes: Boolean) {
        chatRepo.voteOnPlace(placeId, userId, yes)
    }

    fun loadWeather(lat: Double, lon: Double) {
        viewModelScope.launch {
            weatherRepo.getWeather(lat, lon).collect { weather.value = it }
        }
    }

    fun updateLocation(lat: Double, lon: Double) {
        _mapCenter.value = LatLng(lat, lon)
        loadWeather(lat, lon)
    }
}

class MapViewModelFactory(
    private val chatRepo:    ChatRepository,
    private val weatherRepo: WeatherRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(c: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return MapViewModel(chatRepo, weatherRepo) as T
    }
}

// ─────────────────────────────────────────────
// Map Screen
// ─────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    viewModel:     MapViewModel,
    currentUserId: String,
    navController: NavController
) {
    val places        by viewModel.places.collectAsStateWithLifecycle()
    val weather       by viewModel.weather.collectAsStateWithLifecycle()
    val selectedPlace by viewModel.selectedPlace.collectAsStateWithLifecycle()
    val mapCenter     by viewModel.mapCenter.collectAsStateWithLifecycle()

    val context = LocalContext.current

    // Fetch location once on first composition
    LaunchedEffect(Unit) {
        try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val loc    = client.lastLocation.await()
            if (loc != null) viewModel.updateLocation(loc.latitude, loc.longitude)
            else             viewModel.loadWeather(36.806, 10.181)
        } catch (_: SecurityException) {
            viewModel.loadWeather(36.806, 10.181)
        }
    }

    val cameraState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(mapCenter, 12f)
    }

    // Keep camera in sync if location updates
    LaunchedEffect(mapCenter) {
        cameraState.position = CameraPosition.fromLatLngZoom(mapCenter, 12f)
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ── Live cloud sky behind the map controls ────────────────────────
        // (Only visible in the top header strip above the map)
        CloudBackground(
            cloudCoverage = weather.cloudCoverage,
            modifier      = Modifier
                .fillMaxWidth()
                .height(160.dp)
        )

        Column(modifier = Modifier.fillMaxSize()) {

            // ── Header ──────────────────────────────────────────────────────
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    "Shared Map",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(8.dp))
                if (!weather.isLoading) {
                    WeatherHeaderBanner(weather, modifier = Modifier.fillMaxWidth())
                }
            }

            // ── Google Map ──────────────────────────────────────────────────
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                GoogleMap(
                    cameraPositionState = cameraState,
                    properties = MapProperties(isMyLocationEnabled = false),
                    uiSettings = MapUiSettings(
                        zoomControlsEnabled  = false,
                        myLocationButtonEnabled = false
                    ),
                    modifier = Modifier.fillMaxSize()
                ) {
                    places.forEach { place ->
                        PlaceMarker(
                            place      = place,
                            isSelected = selectedPlace?.id == place.id,
                            weather    = weather,
                            onClick    = { viewModel.selectPlace(place) }
                        )
                    }
                }

                // My-location FAB
                FloatingActionButton(
                    onClick = {
                        /* re-trigger location — handled in LaunchedEffect */
                    },
                    containerColor = Color.White,
                    contentColor   = SkyBlue,
                    modifier       = Modifier
                        .align(Alignment.TopEnd)
                        .padding(12.dp)
                        .size(44.dp)
                ) { Icon(Icons.Default.MyLocation, null, modifier = Modifier.size(20.dp)) }
            }

            // ── Horizontal card rail of suggested places ────────────────────
            if (places.isNotEmpty()) {
                Text(
                    "Suggestions (${places.size})",
                    style    = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp)
                )
                LazyRow(
                    contentPadding      = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier            = Modifier.fillMaxWidth()
                ) {
                    items(places, key = { it.id }) { place ->
                        PlaceCard(
                            place     = place,
                            isSelected = selectedPlace?.id == place.id,
                            weather   = weather,
                            onClick   = { viewModel.selectPlace(place) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
            } else {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier         = Modifier
                        .fillMaxWidth()
                        .padding(24.dp)
                ) {
                    Text(
                        "No places suggested yet.\nGo to Chat and tap 📍 to suggest one!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextMuted
                    )
                }
            }
        }

        // ── Vote bottom sheet ───────────────────────────────────────────────
        AnimatedVisibility(
            visible = selectedPlace != null,
            enter   = slideInVertically { it } + fadeIn(),
            exit    = slideOutVertically { it } + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            selectedPlace?.let { place ->
                Surface(
                    shape        = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                    shadowElevation = 16.dp,
                    modifier     = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                "Vote: ${place.name}",
                                style    = MaterialTheme.typography.titleMedium,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton({ viewModel.selectPlace(null) }) {
                                Icon(Icons.Default.Close, null)
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        PlaceSuggestionCard(
                            place         = place,
                            currentUserId = currentUserId,
                            onVoteYes     = { viewModel.vote(place.id, currentUserId, true) },
                            onVoteNo      = { viewModel.vote(place.id, currentUserId, false) }
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────
// Map Marker
// ─────────────────────────────────────────────

@Composable
private fun PlaceMarker(
    place:      PlaceSuggestion,
    isSelected: Boolean,
    weather:    WeatherData,
    onClick:    () -> Unit
) {
    val icon = BitmapDescriptorFactory.defaultMarker(
        if (isSelected) BitmapDescriptorFactory.HUE_AZURE
        else            BitmapDescriptorFactory.HUE_RED
    )
    MarkerInfoWindowContent(
        state   = MarkerState(position = LatLng(place.latitude, place.longitude)),
        title   = place.name,
        icon    = icon,
        onClick = { onClick(); false }
    ) {
        Surface(shape = RoundedCornerShape(10.dp), color = Color.White) {
            Column(Modifier.padding(10.dp)) {
                Text(place.name, fontWeight = FontWeight.Bold)
                Text("${place.yesCount} ✅  ${place.noCount} ❌",
                     style = MaterialTheme.typography.labelSmall)
                Text(weatherEmoji(weather.cloudCoverage) + " ${weather.temperature.toInt()}°C",
                     style = MaterialTheme.typography.labelSmall, color = TextMuted)
            }
        }
    }
}

// ─────────────────────────────────────────────
// Horizontal Place Card
// ─────────────────────────────────────────────

@Composable
private fun PlaceCard(
    place:     PlaceSuggestion,
    isSelected: Boolean,
    weather:   WeatherData,
    onClick:   () -> Unit
) {
    val border = if (isSelected) SkyBlue else Color.Transparent
    Surface(
        onClick      = onClick,
        shape        = RoundedCornerShape(14.dp),
        color        = if (isSelected) SkyBlueLight else Color.White,
        border       = androidx.compose.foundation.BorderStroke(1.5.dp, border),
        shadowElevation = 4.dp,
        modifier     = Modifier.width(200.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("📍 ${place.name}", style = MaterialTheme.typography.titleMedium,
                 maxLines = 1)
            if (place.address.isNotBlank())
                Text(place.address, style = MaterialTheme.typography.bodyMedium,
                     color = TextMuted, maxLines = 1)
            Text("${weatherEmoji(weather.cloudCoverage)} ${weather.temperature.toInt()}°C",
                 style = MaterialTheme.typography.labelMedium, color = SkyBlue)
            Text("✅ ${place.yesCount}  ❌ ${place.noCount}",
                 style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
    }
}
