package com.weatherplan.app.data.repository

import com.weatherplan.app.data.model.ChatMessage
import com.weatherplan.app.data.model.MessageType
import com.weatherplan.app.data.model.PlaceSuggestion
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Single source of truth for chat messages AND place suggestions.
 * Both ChatViewModel and MapViewModel read from the same instance (via AppContainer),
 * so a place suggested in chat appears on the map immediately.
 */
class ChatRepository {

    // Seed with some demo messages to show on first launch
    private val _messages = MutableStateFlow(demoMessages())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _places = MutableStateFlow<List<PlaceSuggestion>>(emptyList())
    val places: StateFlow<List<PlaceSuggestion>> = _places.asStateFlow()

    fun sendMessage(message: ChatMessage) {
        _messages.update { it + message }
        if (message.type == MessageType.PLACE_SUGGESTION) {
            message.placeSuggestion?.let { place ->
                _places.update { it + place }
            }
        }
    }

    fun voteOnPlace(placeId: String, userId: String, vote: Boolean) {
        _places.update { list ->
            list.map { place ->
                if (place.id == placeId) place.copy(votes = place.votes + (userId to vote))
                else place
            }
        }
    }

    fun removePlace(placeId: String) {
        _places.update { it.filter { p -> p.id != placeId } }
    }

    // ─── Demo seed data ───────────────────────────────────────────────────────

    private fun demoMessages() = listOf(
        ChatMessage(
            senderId = "sara", senderName = "Sara B.",
            senderAvatarColor = 0xFF2DC98A,
            content = "Hey everyone! ☀️ Weather looks amazing today — should we go out?",
            timestamp = System.currentTimeMillis() - 7_200_000
        ),
        ChatMessage(
            senderId = "karim", senderName = "Karim O.",
            senderAvatarColor = 0xFF9B59B6,
            content = "100%! I was thinking the beach — La Goulette is always great on sunny days 🏖️",
            timestamp = System.currentTimeMillis() - 3_600_000
        ),
        ChatMessage(
            senderId = "system", senderName = "WeatherPlan",
            senderAvatarColor = 0xFF2A7FE8,
            content = "☀️ Live update: 24 °C, cloud cover 12% — perfect conditions to go out!",
            timestamp = System.currentTimeMillis() - 1_800_000,
            type = MessageType.SYSTEM
        ),
        ChatMessage(
            senderId = "sara", senderName = "Sara B.",
            senderAvatarColor = 0xFF2DC98A,
            content = "Pinned a spot! Vote below 👇",
            timestamp = System.currentTimeMillis() - 900_000,
            type = MessageType.PLACE_SUGGESTION,
            placeSuggestion = PlaceSuggestion(
                name = "La Goulette Beach",
                address = "La Goulette, Tunis Governorate",
                latitude = 36.818,
                longitude = 10.305,
                suggestedById = "sara",
                suggestedByName = "Sara B.",
                votes = mapOf("karim" to true)
            )
        )
    )
}
