package com.weatherplan.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.weatherplan.app.data.model.WeatherCondition
import com.weatherplan.app.ui.theme.*

/**
 * Full-screen animated sky background driven by a real cloud-coverage percentage (0-100).
 *
 *  0 – 19 %  → clear blue sky + bright sun
 * 20 – 49 %  → partly cloudy, soft blues
 * 50 – 74 %  → overcast, blue-grey tones
 * 75 – 100 % → heavy cloud cover, dark grey
 *
 * Clouds are drawn with Canvas bezier paths and animated across the screen
 * using InfiniteTransition at three independent speeds (parallax effect).
 */
@Composable
fun CloudBackground(
    cloudCoverage: Int,
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit = {}
) {
    // ── Sky gradient colours (smoothly animated on coverage change) ───────────

    val skyTop by animateColorAsState(
        targetValue = when {
            cloudCoverage < 20 -> ClearSkyTop
            cloudCoverage < 50 -> PartlyCloudyTop
            cloudCoverage < 75 -> CloudyTop
            else               -> OvercastTop
        },
        animationSpec = tween(3_000),
        label = "sky_top"
    )
    val skyBottom by animateColorAsState(
        targetValue = when {
            cloudCoverage < 20 -> ClearSkyBottom
            cloudCoverage < 50 -> PartlyCloudyBot
            cloudCoverage < 75 -> CloudyBot
            else               -> OvercastBot
        },
        animationSpec = tween(3_000),
        label = "sky_bottom"
    )

    // Cloud opacity tracks coverage linearly
    val cloudAlpha by animateFloatAsState(
        targetValue = (cloudCoverage / 100f).coerceIn(0f, 1f),
        animationSpec = tween(2_000),
        label = "cloud_alpha"
    )

    val sunAlpha by animateFloatAsState(
        targetValue = if (cloudCoverage < 50) (1f - cloudCoverage / 50f) else 0f,
        animationSpec = tween(2_000),
        label = "sun_alpha"
    )

    // ── Cloud motion (three independent speeds = parallax layers) ────────────

    val inf = rememberInfiniteTransition(label = "clouds")

    // Layer 1 — distant, small, fast
    val c1x by inf.animateFloat(
        initialValue = -400f, targetValue = 1600f,
        animationSpec = infiniteRepeatable(tween(18_000, easing = LinearEasing), RepeatMode.Restart),
        label = "c1x"
    )
    // Layer 2 — mid, medium, medium speed
    val c2x by inf.animateFloat(
        initialValue = 300f, targetValue = 2100f,
        animationSpec = infiniteRepeatable(tween(27_000, easing = LinearEasing), RepeatMode.Restart),
        label = "c2x"
    )
    // Layer 3 — foreground, large, slow (only visible when coverage > 30%)
    val c3x by inf.animateFloat(
        initialValue = -700f, targetValue = 1500f,
        animationSpec = infiniteRepeatable(tween(40_000, easing = LinearEasing), RepeatMode.Restart),
        label = "c3x"
    )
    // A fourth wispy thin cloud for heavy overcast
    val c4x by inf.animateFloat(
        initialValue = 800f, targetValue = 2400f,
        animationSpec = infiniteRepeatable(tween(22_000, easing = LinearEasing), RepeatMode.Restart),
        label = "c4x"
    )

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {

            // 1. Sky gradient
            drawRect(
                brush = Brush.verticalGradient(
                    colors = listOf(skyTop, skyBottom),
                    startY = 0f,
                    endY   = size.height
                )
            )

            // 2. Sun (only when clear/partly cloudy)
            if (sunAlpha > 0f) {
                val sx = size.width * 0.82f
                val sy = size.height * 0.14f
                // Outer glow
                drawCircle(Color(0xFFFFF176).copy(alpha = sunAlpha * 0.25f), 110f, Offset(sx, sy))
                // Inner glow
                drawCircle(Color(0xFFFDD835).copy(alpha = sunAlpha * 0.55f), 72f,  Offset(sx, sy))
                // Core
                drawCircle(Color(0xFFFFEE58).copy(alpha = sunAlpha), 52f, Offset(sx, sy))
            }

            // 3. Cloud layers — each only drawn if coverage warrants it

            // Layer 1: thin wispy high clouds (visible from 10%)
            if (cloudCoverage >= 10) {
                drawCloud(
                    x = c1x,   y = size.height * 0.08f,
                    scaleX = 1.2f, scaleY = 0.5f,
                    alpha  = cloudAlpha * 0.55f,
                    baseColor = Color.White
                )
                // second cloud on same layer, offset half a screen
                drawCloud(
                    x = c1x + size.width * 0.55f, y = size.height * 0.12f,
                    scaleX = 0.9f, scaleY = 0.45f,
                    alpha  = cloudAlpha * 0.45f,
                    baseColor = Color.White
                )
            }

            // Layer 2: mid clouds (visible from 20%)
            if (cloudCoverage >= 20) {
                drawCloud(
                    x = c2x,   y = size.height * 0.22f,
                    scaleX = 1.6f, scaleY = 0.9f,
                    alpha  = cloudAlpha * 0.75f,
                    baseColor = cloudColor(cloudCoverage)
                )
                drawCloud(
                    x = c2x - size.width * 0.7f, y = size.height * 0.28f,
                    scaleX = 1.1f, scaleY = 0.7f,
                    alpha  = cloudAlpha * 0.65f,
                    baseColor = cloudColor(cloudCoverage)
                )
            }

            // Layer 3: large foreground clouds (visible from 30%)
            if (cloudCoverage >= 30) {
                drawCloud(
                    x = c3x,   y = size.height * 0.38f,
                    scaleX = 2.0f, scaleY = 1.2f,
                    alpha  = cloudAlpha * 0.85f,
                    baseColor = cloudColor(cloudCoverage)
                )
            }

            // Layer 4: heavy overcast blobs (visible from 60%)
            if (cloudCoverage >= 60) {
                drawCloud(
                    x = c4x,   y = size.height * 0.48f,
                    scaleX = 2.5f, scaleY = 1.4f,
                    alpha  = (cloudAlpha - 0.3f).coerceAtLeast(0f),
                    baseColor = Color(0xFFB0BEC5)
                )
                // Cover the top with a dark overcast sheet
                drawRect(
                    color  = Color(0xFF37474F).copy(alpha = ((cloudCoverage - 60) / 100f) * 0.35f),
                    topLeft = Offset.Zero,
                    size   = androidx.compose.ui.geometry.Size(size.width, size.height * 0.5f)
                )
            }
        }

        // App content sits on top
        content()
    }
}

/** Returns the appropriate cloud fill colour for the current coverage level */
private fun cloudColor(coverage: Int): Color = when {
    coverage > 75 -> Color(0xFFB0BEC5)  // dark grey
    coverage > 50 -> Color(0xFFCFD8DC)  // mid grey
    else          -> Color(0xFFF5F5F5)  // near-white
}

/**
 * Draws a single organic cloud shape at [x],[y] using cubic Bézier curves.
 *
 * The cloud is drawn in a normalised unit space then scaled by [scaleX]/[scaleY].
 * [alpha] lets the caller fade clouds in/out based on coverage.
 */
private fun DrawScope.drawCloud(
    x: Float,
    y: Float,
    scaleX: Float = 1f,
    scaleY: Float = 1f,
    alpha: Float = 1f,
    baseColor: Color = Color.White
) {
    if (alpha <= 0f) return

    val w = 160f * scaleX   // cloud width
    val h = 60f  * scaleY   // cloud height

    val path = Path().apply {
        // Start bottom-left
        moveTo(x, y + h)

        // Left bump
        cubicTo(
            x,            y + h * 0.5f,
            x + w * 0.08f,y + h * 0.1f,
            x + w * 0.2f, y + h * 0.15f
        )
        // Centre-left peak
        cubicTo(
            x + w * 0.22f, y - h * 0.3f,
            x + w * 0.45f, y - h * 0.5f,
            x + w * 0.5f,  y
        )
        // Centre-right peak
        cubicTo(
            x + w * 0.52f, y - h * 0.6f,
            x + w * 0.72f, y - h * 0.55f,
            x + w * 0.78f, y - h * 0.1f
        )
        // Right bump
        cubicTo(
            x + w * 0.82f, y - h * 0.2f,
            x + w,         y + h * 0.2f,
            x + w,         y + h
        )
        close()
    }

    // Soft shadow / depth
    drawPath(path, color = Color.Black.copy(alpha = alpha * 0.06f),
        style = androidx.compose.ui.graphics.drawscope.Fill)

    // Main cloud body
    drawPath(path, color = baseColor.copy(alpha = alpha))
}
