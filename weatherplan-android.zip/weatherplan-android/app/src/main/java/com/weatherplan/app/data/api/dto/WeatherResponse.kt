package com.weatherplan.app.data.api.dto

import com.google.gson.annotations.SerializedName

data class WeatherResponse(
    @SerializedName("name")    val cityName: String            = "",
    @SerializedName("clouds")  val clouds: CloudsDto           = CloudsDto(),
    @SerializedName("main")    val main: MainDto               = MainDto(),
    @SerializedName("weather") val weather: List<WeatherDescDto> = emptyList(),
    @SerializedName("wind")    val wind: WindDto               = WindDto()
)

data class CloudsDto(
    @SerializedName("all") val coverage: Int = 0
)

data class MainDto(
    @SerializedName("temp")       val temp: Double = 20.0,
    @SerializedName("feels_like") val feelsLike: Double = 20.0,
    @SerializedName("humidity")   val humidity: Int = 50
)

data class WeatherDescDto(
    @SerializedName("description") val description: String = "",
    @SerializedName("icon")        val icon: String = "01d"
)

data class WindDto(
    @SerializedName("speed") val speed: Double = 0.0
)
