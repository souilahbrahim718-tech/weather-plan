package com.weatherplan.app.di

import com.weatherplan.app.data.api.NetworkClient
import com.weatherplan.app.data.repository.ChatRepository
import com.weatherplan.app.data.repository.FriendRepository
import com.weatherplan.app.data.repository.WeatherRepository

/**
 * Manual dependency-injection container.
 * All repositories are singletons so Chat and Map share the same PlaceSuggestion state.
 * Swap this for a Hilt @Singleton module if you migrate to Hilt.
 */
class AppContainer {
    private val networkClient = NetworkClient()

    val weatherRepository = WeatherRepository(networkClient.weatherApiService)

    // Shared between ChatViewModel & MapViewModel — one source of truth for places
    val chatRepository = ChatRepository()

    val friendRepository = FriendRepository()
}
