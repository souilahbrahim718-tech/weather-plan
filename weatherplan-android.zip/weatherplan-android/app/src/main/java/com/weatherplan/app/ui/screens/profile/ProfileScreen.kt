package com.weatherplan.app.ui.screens.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import com.weatherplan.app.data.model.User
import com.weatherplan.app.ui.components.Avatar
import com.weatherplan.app.ui.components.CloudBackground
import com.weatherplan.app.ui.components.GoOutScoreChip
import com.weatherplan.app.ui.components.weatherEmoji
import com.weatherplan.app.ui.theme.*

// ─────────────────────────────────────────────
// ViewModel
// ─────────────────────────────────────────────

class ProfileViewModel : ViewModel() {
    // Extend here: edit bio, upload photo, etc.
}

// ─────────────────────────────────────────────
// Screen
// ─────────────────────────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    viewModel:    ProfileViewModel,
    user:         User,
    onLogout:     () -> Unit,
    navController: NavController
) {
    var showLogoutDialog by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {

        // ── Profile Header with CloudBackground ────────────────────────────
        CloudBackground(
            cloudCoverage = 15,
            modifier      = Modifier.fillMaxWidth().height(250.dp)
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxSize().padding(24.dp)
            ) {
                Avatar(user.avatarLetter, user.avatarColor, size = 72.dp)
                Spacer(Modifier.height(12.dp))
                Text(user.name,
                     style = MaterialTheme.typography.headlineMedium,
                     fontWeight = FontWeight.Bold, color = Color.White)
                Text(user.username,
                     style = MaterialTheme.typography.bodyLarge,
                     color = Color.White.copy(0.8f))

                Spacer(Modifier.height(16.dp))

                // Stats row
                Row(
                    horizontalArrangement = Arrangement.spacedBy(1.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color.White.copy(0.15f))
                ) {
                    StatItem("12", "Outings")
                    VerticalDivider(color = Color.White.copy(0.3f), thickness = 1.dp,
                                   modifier = Modifier.height(48.dp))
                    StatItem("5", "Friends")
                    VerticalDivider(color = Color.White.copy(0.3f), thickness = 1.dp,
                                   modifier = Modifier.height(48.dp))
                    StatItem("8", "Posts")
                }
            }
        }

        // ── Body ────────────────────────────────────────────────────────────
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {

            // Account info card
            ProfileSection(title = "Account") {
                ProfileRow(Icons.Default.Email, "Email", user.email)
                ProfileRow(Icons.Default.Person, "Username", user.username)
                if (user.bio.isNotBlank())
                    ProfileRow(Icons.Default.Info, "Bio", user.bio)
            }

            // Weather preferences
            ProfileSection(title = "My Weather Preferences") {
                ProfileRow(Icons.Default.WbSunny, "Favourite condition", "☀️ Sunny")
                ProfileRow(Icons.Default.Thermostat, "Comfort temperature", "18 – 28 °C")
            }

            // Recent activity
            ProfileSection(title = "Recent Activity") {
                ActivityRow("🏖️", "La Goulette Beach outing", "Last Saturday · ☀️ 26°C")
                ActivityRow("☕", "Café Saf Saf meetup", "3 days ago · ⛅ 21°C")
                ActivityRow("🌳", "Parc Ennahli walk", "Last week · 🌤️ 23°C")
            }

            // Danger zone
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick  = { showLogoutDialog = true },
                shape    = RoundedCornerShape(14.dp),
                colors   = ButtonDefaults.outlinedButtonColors(contentColor = RedNo),
                border   = androidx.compose.foundation.BorderStroke(1.dp, RedNo),
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Icon(Icons.Default.Logout, null, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Sign Out", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title   = { Text("Sign out?") },
            text    = { Text("You'll need to sign in again to access WeatherPlan.") },
            confirmButton = {
                Button(
                    onClick = { showLogoutDialog = false; onLogout() },
                    colors  = ButtonDefaults.buttonColors(containerColor = RedNo)
                ) { Text("Sign out") }
            },
            dismissButton = {
                TextButton({ showLogoutDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ─────────────────────────────────────────────
// Reusable sub-components
// ─────────────────────────────────────────────

@Composable
private fun ProfileSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Surface(shape = RoundedCornerShape(16.dp), color = Color.White, shadowElevation = 2.dp) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium,
                 fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
private fun ProfileRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Icon(icon, null, tint = SkyBlue, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(12.dp))
        Text(label, style = MaterialTheme.typography.bodyMedium, color = TextMuted,
             modifier = Modifier.width(110.dp))
        Text(value, style = MaterialTheme.typography.bodyMedium, color = TextPrimary,
             modifier = Modifier.weight(1f))
    }
}

@Composable
private fun ActivityRow(emoji: String, title: String, subtitle: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
    ) {
        Text(emoji, fontSize = 22.sp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodyLarge, color = TextPrimary)
            Text(subtitle, style = MaterialTheme.typography.labelSmall, color = TextMuted)
        }
    }
}

@Composable
private fun StatItem(number: String, label: String) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
    ) {
        Text(number, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Color.White)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(0.75f))
    }
}
