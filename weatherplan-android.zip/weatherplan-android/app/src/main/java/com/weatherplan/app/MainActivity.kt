package com.weatherplan.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import com.weatherplan.app.ui.navigation.WeatherPlanNavGraph
import com.weatherplan.app.ui.theme.WeatherPlanTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val container = (application as WeatherPlanApp).container

        setContent {
            WeatherPlanTheme {
                WeatherPlanNavGraph(container = container)
            }
        }
    }
}
