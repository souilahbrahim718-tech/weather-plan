package com.weatherplan.app.ui.screens.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.weatherplan.app.data.model.User
import com.weatherplan.app.ui.components.AvatarColors
import com.weatherplan.app.ui.components.CloudBackground
import com.weatherplan.app.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

// ─────────────────────────────────────────────
// ViewModel
// ─────────────────────────────────────────────

class AuthViewModel : ViewModel() {

    private val _currentUser = MutableStateFlow(
        User(id = "me", name = "Ahmed Ben Ali", username = "@ahmed_tunis",
             email = "ahmed@example.com", avatarColor = 0xFF2A7FE8)
    )
    val currentUser: StateFlow<User> = _currentUser.asStateFlow()

    fun login(email: String, password: String): Boolean {
        // TODO: replace with real auth (Firebase / backend JWT)
        return email.isNotBlank() && password.length >= 6
    }

    fun register(name: String, username: String, email: String, password: String, avatarColor: Long): Boolean {
        if (name.isBlank() || email.isBlank() || password.length < 6) return false
        _currentUser.value = User(
            name        = name,
            username    = if (username.startsWith("@")) username else "@$username",
            email       = email,
            avatarColor = avatarColor
        )
        return true
    }

    fun updateUser(user: User) { _currentUser.value = user }
}

class AuthViewModelFactory : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        @Suppress("UNCHECKED_CAST")
        return AuthViewModel() as T
    }
}

// ─────────────────────────────────────────────
// Login Screen
// ─────────────────────────────────────────────

@Composable
fun LoginScreen(
    viewModel:     AuthViewModel,
    onLoginSuccess: () -> Unit,
    onGoToRegister: () -> Unit
) {
    var email    by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    var error    by remember { mutableStateOf("") }

    CloudBackground(cloudCoverage = 20) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Logo
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(72.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(SkyBlue)
            ) { Text("🌤️", fontSize = 34.sp) }

            Spacer(Modifier.height(12.dp))
            Text("WeatherPlan", fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Color.White)
            Text("Go out together, at the right time",
                 style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(0.75f))

            Spacer(Modifier.height(36.dp))

            // Card
            Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 8.dp) {
                Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Sign In", style = MaterialTheme.typography.titleLarge, color = TextPrimary)

                    // Email
                    OutlinedTextField(
                        value = email, onValueChange = { email = it },
                        label = { Text("Email") },
                        leadingIcon = { Icon(Icons.Default.Email, null) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    // Password
                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        label = { Text("Password") },
                        leadingIcon  = { Icon(Icons.Default.Lock, null) },
                        trailingIcon = {
                            IconButton({ showPass = !showPass }) {
                                Icon(if (showPass) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                            }
                        },
                        visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (error.isNotBlank())
                        Text(error, color = RedNo, style = MaterialTheme.typography.labelMedium)

                    // Sign In button
                    Button(
                        onClick = {
                            if (viewModel.login(email, password)) onLoginSuccess()
                            else error = "Invalid email or password (min 6 chars)"
                        },
                        shape  = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SkyBlue),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) { Text("Sign In", fontWeight = FontWeight.Bold, fontSize = 15.sp) }

                    // Register link
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("No account? ", color = TextMuted, style = MaterialTheme.typography.bodyMedium)
                        Text(
                            "Create one",
                            color = SkyBlue, fontWeight = FontWeight.SemiBold,
                            style = MaterialTheme.typography.bodyMedium,
                            modifier = Modifier.clickable { onGoToRegister() }
                        )
                    }
                }
            }
        }
    }
}

// ─────────────────────────────────────────────
// Register Screen
// ─────────────────────────────────────────────

@Composable
fun RegisterScreen(
    viewModel:         AuthViewModel,
    onRegisterSuccess: () -> Unit,
    onGoToLogin:       () -> Unit
) {
    var name       by remember { mutableStateOf("") }
    var username   by remember { mutableStateOf("") }
    var email      by remember { mutableStateOf("") }
    var password   by remember { mutableStateOf("") }
    var showPass   by remember { mutableStateOf(false) }
    var selectedColor by remember { mutableStateOf(AvatarColors[0].value.toLong()) }
    var error      by remember { mutableStateOf("") }

    CloudBackground(cloudCoverage = 30) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 24.dp, vertical = 48.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Surface(shape = RoundedCornerShape(20.dp), color = Color.White, shadowElevation = 8.dp) {
                Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Create Account 🚀", style = MaterialTheme.typography.titleLarge)

                    // Avatar colour picker
                    Text("Pick your colour", style = MaterialTheme.typography.labelMedium, color = TextMuted)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        AvatarColors.take(6).forEach { color ->
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(color)
                                    .clickable { selectedColor = color.value.toLong() }
                            ) {
                                if (selectedColor == color.value.toLong())
                                    Text("✓", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                        }
                    }

                    OutlinedTextField(value = name, onValueChange = { name = it },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, null) },
                        singleLine = true, shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth())

                    OutlinedTextField(value = username, onValueChange = { username = it },
                        label = { Text("Username") },
                        prefix = { Text("@") },
                        singleLine = true, shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth())

                    OutlinedTextField(value = email, onValueChange = { email = it },
                        label = { Text("Email") },
                        leadingIcon = { Icon(Icons.Default.Email, null) },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                        shape = RoundedCornerShape(12.dp), modifier = Modifier.fillMaxWidth())

                    OutlinedTextField(
                        value = password, onValueChange = { password = it },
                        label = { Text("Password") },
                        leadingIcon = { Icon(Icons.Default.Lock, null) },
                        trailingIcon = {
                            IconButton({ showPass = !showPass }) {
                                Icon(if (showPass) Icons.Default.VisibilityOff else Icons.Default.Visibility, null)
                            }
                        },
                        visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                        singleLine = true, shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth())

                    if (error.isNotBlank())
                        Text(error, color = RedNo, style = MaterialTheme.typography.labelMedium)

                    Button(
                        onClick = {
                            if (viewModel.register(name, username, email, password, selectedColor))
                                onRegisterSuccess()
                            else
                                error = "Please fill all fields (password ≥ 6 chars)"
                        },
                        shape  = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SkyBlue),
                        modifier = Modifier.fillMaxWidth().height(50.dp)
                    ) { Text("Create my account", fontWeight = FontWeight.Bold, fontSize = 15.sp) }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Text("Already registered? ", color = TextMuted,
                             style = MaterialTheme.typography.bodyMedium)
                        Text("Sign in", color = SkyBlue, fontWeight = FontWeight.SemiBold,
                             style = MaterialTheme.typography.bodyMedium,
                             modifier = Modifier.clickable { onGoToLogin() })
                    }
                }
            }
        }
    }
}
