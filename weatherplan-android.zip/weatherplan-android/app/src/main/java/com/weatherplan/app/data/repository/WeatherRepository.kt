package com.weatherplan.app.data.repository

import com.weatherplan.app.BuildConfig
import com.weatherplan.app.data.api.WeatherApiService
import com.weatherplan.app.data.model.WeatherData
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

class WeatherRepository(private val api: WeatherApiService) {

    /**
     * Emits a loading state immediately, then the real data (or error).
     */
    fun getWeather(lat: Double, lon: Double): Flow<WeatherData> = flow {
        emit(WeatherData(isLoading = true))
        try {
            val resp = api.getCurrentWeather(
                latitude  = lat,
                longitude = lon,
                apiKey    = BuildConfig.WEATHER_API_KEY
            )
            emit(
                WeatherData(
                    cityName      = resp.cityName,
                    temperature   = resp.main.temp,
                    feelsLike     = resp.main.feelsLike,
                    humidity      = resp.main.humidity,
                    cloudCoverage = resp.clouds.coverage,
                    windSpeed     = resp.wind.speed,
                    description   = resp.weather.firstOrNull()?.description?.replaceFirstChar { it.uppercase() }
                                    ?: "Clear sky",
                    iconCode      = resp.weather.firstOrNull()?.icon ?: "01d",
                    isLoading     = false
                )
            )
        } catch (e: Exception) {
            emit(
                WeatherData(
                    isLoading = false,
                    error     = e.localizedMessage ?: "Network error"
                )
            )
        }
    }
}
