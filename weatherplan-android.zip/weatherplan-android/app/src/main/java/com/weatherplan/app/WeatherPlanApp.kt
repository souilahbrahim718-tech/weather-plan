package com.weatherplan.app

import android.app.Application
import com.weatherplan.app.di.AppContainer

class WeatherPlanApp : Application() {
    // Manual DI container — replace with Hilt if preferred
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer()
    }
}
