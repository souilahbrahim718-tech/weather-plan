package com.weatherplan.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.weatherplan.app.di.AppContainer
import com.weatherplan.app.ui.screens.auth.LoginScreen
import com.weatherplan.app.ui.screens.auth.RegisterScreen
import com.weatherplan.app.ui.screens.auth.AuthViewModel
import com.weatherplan.app.ui.screens.auth.AuthViewModelFactory
import com.weatherplan.app.ui.screens.chat.ChatViewModel
import com.weatherplan.app.ui.screens.chat.ChatViewModelFactory
import com.weatherplan.app.ui.screens.friends.FriendsViewModel
import com.weatherplan.app.ui.screens.friends.FriendsViewModelFactory
import com.weatherplan.app.ui.screens.home.MainScreen
import com.weatherplan.app.ui.screens.map.MapViewModel
import com.weatherplan.app.ui.screens.map.MapViewModelFactory
import com.weatherplan.app.ui.screens.profile.ProfileViewModel

// ─────────────────────────────────────────────
// Route definitions
// ─────────────────────────────────────────────

sealed class Screen(val route: String) {
    object Login    : Screen("login")
    object Register : Screen("register")
    object Main     : Screen("main")   // host for all tabbed screens
    // Individual tab routes kept for deep-linking
    object Home     : Screen("home")
    object Chat     : Screen("chat")
    object Map      : Screen("map")
    object Friends  : Screen("friends")
    object Profile  : Screen("profile")
}

data class BottomNavItem(
    val screen:       Screen,
    val label:        String,
    val iconFilled:   ImageVector,
    val iconOutlined: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Home,    "Home",    Icons.Filled.Home,   Icons.Outlined.Home),
    BottomNavItem(Screen.Chat,    "Chat",    Icons.Filled.Chat,   Icons.Outlined.Chat),
    BottomNavItem(Screen.Map,     "Map",     Icons.Filled.Map,    Icons.Outlined.Map),
    BottomNavItem(Screen.Friends, "Friends", Icons.Filled.Group,  Icons.Outlined.Group),
    BottomNavItem(Screen.Profile, "Me",      Icons.Filled.Person, Icons.Outlined.Person),
)

// ─────────────────────────────────────────────
// Navigation graph
// ─────────────────────────────────────────────

@Composable
fun WeatherPlanNavGraph(container: AppContainer) {
    val navController = rememberNavController()

    // Auth ViewModel — shared across Login + Register
    val authVM: AuthViewModel = viewModel(factory = AuthViewModelFactory())

    // App-level ViewModels — single instances live for the whole session
    val chatVM: ChatViewModel     = viewModel(factory = ChatViewModelFactory(container.chatRepository, container.weatherRepository))
    val mapVM:  MapViewModel      = viewModel(factory = MapViewModelFactory(container.chatRepository,  container.weatherRepository))
    val friendsVM: FriendsViewModel = viewModel(factory = FriendsViewModelFactory(container.friendRepository))
    val profileVM: ProfileViewModel = viewModel()

    val currentUser by authVM.currentUser

    NavHost(
        navController    = navController,
        startDestination = Screen.Login.route
    ) {
        composable(Screen.Login.route) {
            LoginScreen(
                viewModel       = authVM,
                onLoginSuccess  = {
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onGoToRegister  = { navController.navigate(Screen.Register.route) }
            )
        }

        composable(Screen.Register.route) {
            RegisterScreen(
                viewModel         = authVM,
                onRegisterSuccess = {
                    // Sync user into ChatViewModel so name shows correctly
                    chatVM.updateCurrentUser(authVM.currentUser.value)
                    navController.navigate(Screen.Main.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onGoToLogin = { navController.popBackStack() }
            )
        }

        composable(Screen.Main.route) {
            MainScreen(
                chatViewModel    = chatVM,
                mapViewModel     = mapVM,
                friendsViewModel = friendsVM,
                profileViewModel = profileVM,
                currentUser      = authVM.currentUser.value,
                onLogout         = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(0) { inclusive = true }
                    }
                },
                navController    = navController
            )
        }
    }
}
