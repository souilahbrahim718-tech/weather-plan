package com.weatherplan.app.data.api

import com.weatherplan.app.data.api.dto.WeatherResponse
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

// ─────────────────────────────────────────────
// Retrofit service interface
// ─────────────────────────────────────────────

interface WeatherApiService {
    @GET("weather")
    suspend fun getCurrentWeather(
        @Query("lat")   latitude:  Double,
        @Query("lon")   longitude: Double,
        @Query("appid") apiKey:    String,
        @Query("units") units:     String = "metric"
    ): WeatherResponse
}

// ─────────────────────────────────────────────
// Network client (singleton-safe via class)
// ─────────────────────────────────────────────

class NetworkClient {
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(loggingInterceptor)
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    val weatherApiService: WeatherApiService by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.openweathermap.org/data/2.5/")
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(WeatherApiService::class.java)
    }
}
