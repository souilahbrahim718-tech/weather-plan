package com.weatherplan.app.data.model

import java.util.UUID

// ─────────────────────────────────────────────
// User
// ─────────────────────────────────────────────

data class User(
    val id: String = UUID.randomUUID().toString(),
    val name: String = "",
    val username: String = "",
    val email: String = "",
    val avatarColor: Long = 0xFF2A7FE8,
    val bio: String = "",
    val totalOutings: Int = 0,
    val friendCount: Int = 0
) {
    val avatarLetter: String get() = name.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
    val isComplete: Boolean get() = name.isNotBlank() && email.isNotBlank()
}

// ─────────────────────────────────────────────
// Friend
// ─────────────────────────────────────────────

data class Friend(
    val id: String,
    val name: String,
    val username: String,
    val avatarColor: Long = 0xFF2DC98A,
    val isOnline: Boolean = false,
    val voteStatus: VoteStatus = VoteStatus.PENDING,
    val friendshipStatus: FriendshipStatus = FriendshipStatus.ACCEPTED
) {
    val avatarLetter: String get() = name.firstOrNull()?.uppercaseChar()?.toString() ?: "?"
}

enum class VoteStatus { PENDING, YES, NO, MAYBE }
enum class FriendshipStatus { PENDING_SENT, PENDING_RECEIVED, ACCEPTED }

// ─────────────────────────────────────────────
// Chat
// ─────────────────────────────────────────────

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val senderId: String,
    val senderName: String,
    val senderAvatarColor: Long = 0xFF2A7FE8,
    val content: String,
    val timestamp: Long = System.currentTimeMillis(),
    val type: MessageType = MessageType.TEXT,
    val placeSuggestion: PlaceSuggestion? = null
)

enum class MessageType { TEXT, PLACE_SUGGESTION, SYSTEM }

// ─────────────────────────────────────────────
// Place Suggestion
// ─────────────────────────────────────────────

data class PlaceSuggestion(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val address: String = "",
    val latitude: Double,
    val longitude: Double,
    val suggestedById: String,
    val suggestedByName: String,
    val weatherSuitability: WeatherSuitability = WeatherSuitability.GOOD,
    val votes: Map<String, Boolean> = emptyMap(),   // userId → true=YES, false=NO
    val timestamp: Long = System.currentTimeMillis()
) {
    val yesCount: Int get() = votes.values.count { it }
    val noCount: Int get() = votes.values.count { !it }
    val totalVotes: Int get() = votes.size
}

enum class WeatherSuitability(val label: String, val emoji: String) {
    GREAT("Great", "🌟"),
    GOOD("Good", "✅"),
    FAIR("Fair", "⚠️"),
    POOR("Poor weather", "🌧️")
}

// ─────────────────────────────────────────────
// Weather
// ─────────────────────────────────────────────

data class WeatherData(
    val cityName: String = "",
    val temperature: Double = 20.0,
    val feelsLike: Double = 20.0,
    val humidity: Int = 50,
    val cloudCoverage: Int = 0,   // 0 – 100 %
    val windSpeed: Double = 0.0,
    val description: String = "Clear sky",
    val iconCode: String = "01d",
    val isLoading: Boolean = true,
    val error: String? = null
) {
    val condition: WeatherCondition
        get() = when {
            cloudCoverage < 20 -> WeatherCondition.CLEAR
            cloudCoverage < 50 -> WeatherCondition.PARTLY_CLOUDY
            cloudCoverage < 75 -> WeatherCondition.CLOUDY
            else               -> WeatherCondition.OVERCAST
        }

    /** 0-100 score for "should we go out?" */
    val goOutScore: Int
        get() = when {
            cloudCoverage < 20 && temperature in 15.0..30.0 -> 100
            cloudCoverage < 50 && temperature in 10.0..33.0 -> 75
            cloudCoverage < 75                               -> 50
            else                                             -> 25
        }

    val goOutLabel: String
        get() = when {
            goOutScore >= 100 -> "Perfect day to go out! 🌟"
            goOutScore >= 75  -> "Good weather for a trip 👍"
            goOutScore >= 50  -> "Decent, dress in layers 🧥"
            else              -> "Maybe stay in today 🏠"
        }
}

enum class WeatherCondition { CLEAR, PARTLY_CLOUDY, CLOUDY, OVERCAST }
