package com.weatherplan.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val LightColors = lightColorScheme(
    primary          = SkyBlue,
    onPrimary        = Surface,
    primaryContainer = SkyBlueLight,
    secondary        = GreenGo,
    onSecondary      = Surface,
    background       = Background,
    surface          = Surface,
    onBackground     = TextPrimary,
    onSurface        = TextPrimary,
    error            = RedNo
)

private val DarkColors = darkColorScheme(
    primary          = SkyBlueLight,
    onPrimary        = SkyBlueDark,
    primaryContainer = SkyBlueDark,
    secondary        = GreenGo,
    onSecondary      = Surface,
    background       = TextPrimary,
    surface          = Color(0xFF1E1E2E),
    onBackground     = Surface,
    onSurface        = Surface,
    error            = RedNo
)

@Composable
fun WeatherPlanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography  = WeatherPlanTypography,
        content     = content
    )
}

// ─── Typography ──────────────────────────────────────────────────────────────

import androidx.compose.material3.Typography

private val Color get() = androidx.compose.ui.graphics.Color  // alias for below

val WeatherPlanTypography = Typography(
    headlineLarge = TextStyle(fontWeight = FontWeight.Bold,   fontSize = 28.sp, lineHeight = 34.sp),
    headlineMedium= TextStyle(fontWeight = FontWeight.Bold,   fontSize = 22.sp, lineHeight = 28.sp),
    titleLarge    = TextStyle(fontWeight = FontWeight.SemiBold,fontSize = 18.sp, lineHeight = 24.sp),
    titleMedium   = TextStyle(fontWeight = FontWeight.SemiBold,fontSize = 15.sp, lineHeight = 20.sp),
    bodyLarge     = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodyMedium    = TextStyle(fontWeight = FontWeight.Normal, fontSize = 13.sp, lineHeight = 18.sp),
    labelLarge    = TextStyle(fontWeight = FontWeight.SemiBold,fontSize = 13.sp),
    labelMedium   = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp),
    labelSmall    = TextStyle(fontWeight = FontWeight.Medium, fontSize = 11.sp)
)
