package com.weatherplan.app.ui.screens.home

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavController
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.currentBackStackEntryAsState
import com.weatherplan.app.data.model.User
import com.weatherplan.app.ui.navigation.Screen
import com.weatherplan.app.ui.navigation.bottomNavItems
import com.weatherplan.app.ui.screens.chat.ChatViewModel
import com.weatherplan.app.ui.screens.friends.FriendsViewModel
import com.weatherplan.app.ui.screens.map.MapViewModel
import com.weatherplan.app.ui.screens.map.MapScreen
import com.weatherplan.app.ui.screens.chat.ChatScreen
import com.weatherplan.app.ui.screens.friends.FriendsScreen
import com.weatherplan.app.ui.screens.profile.ProfileScreen
import com.weatherplan.app.ui.screens.profile.ProfileViewModel
import com.weatherplan.app.ui.theme.SkyBlue

/**
 * Main scaffold rendered after successful login.
 * Hosts a [NavigationBar] (Material 3) at the bottom and swaps content
 * based on the selected tab — without a nested NavController so that
 * all ViewModels remain alive across tab switches.
 */
@Composable
fun MainScreen(
    chatViewModel:   ChatViewModel,
    mapViewModel:    MapViewModel,
    friendsViewModel: FriendsViewModel,
    profileViewModel: ProfileViewModel,
    currentUser:     User,
    onLogout:        () -> Unit,
    navController:   NavController     // outer nav, used only for logout
) {
    // Which tab is active — persisted across recompositions
    var selectedTab by rememberSaveable { mutableStateOf(0) }

    val tabScreens = listOf(
        Screen.Home, Screen.Chat, Screen.Map, Screen.Friends, Screen.Profile
    )

    Scaffold(
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                bottomNavItems.forEachIndexed { index, item ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick  = { selectedTab = index },
                        icon     = {
                            Icon(
                                if (selectedTab == index) item.iconFilled else item.iconOutlined,
                                contentDescription = item.label
                            )
                        },
                        label    = { Text(item.label) },
                        colors   = NavigationBarItemDefaults.colors(
                            selectedIconColor   = SkyBlue,
                            selectedTextColor   = SkyBlue,
                            indicatorColor      = SkyBlue.copy(alpha = 0.12f),
                            unselectedIconColor = androidx.compose.ui.graphics.Color(0xFF7A7A9A),
                            unselectedTextColor = androidx.compose.ui.graphics.Color(0xFF7A7A9A)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            when (selectedTab) {
                0 -> HomeScreen(chatViewModel = chatViewModel, navController = navController)
                1 -> ChatScreen(viewModel = chatViewModel, navController = navController)
                2 -> MapScreen(viewModel = mapViewModel, currentUserId = currentUser.id,
                               navController = navController)
                3 -> FriendsScreen(viewModel = friendsViewModel, currentUserId = currentUser.id,
                                   navController = navController)
                4 -> ProfileScreen(viewModel = profileViewModel, user = currentUser,
                                   onLogout = onLogout, navController = navController)
            }
        }
    }
}
