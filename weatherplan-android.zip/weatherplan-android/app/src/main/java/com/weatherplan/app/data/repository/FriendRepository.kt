package com.weatherplan.app.data.repository

import com.weatherplan.app.data.model.Friend
import com.weatherplan.app.data.model.FriendshipStatus
import com.weatherplan.app.data.model.VoteStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class FriendRepository {

    private val _friends = MutableStateFlow(demoFriends())
    val friends: StateFlow<List<Friend>> = _friends.asStateFlow()

    /** Pending incoming invites */
    private val _pendingInvites = MutableStateFlow<List<Friend>>(
        listOf(
            Friend("pending1", "Nadia F.", "@nadia_f", 0xFF1ABC9C, false,
                   friendshipStatus = FriendshipStatus.PENDING_RECEIVED)
        )
    )
    val pendingInvites: StateFlow<List<Friend>> = _pendingInvites.asStateFlow()

    fun acceptInvite(friendId: String) {
        val friend = _pendingInvites.value.find { it.id == friendId } ?: return
        _pendingInvites.update { it.filter { f -> f.id != friendId } }
        _friends.update { it + friend.copy(friendshipStatus = FriendshipStatus.ACCEPTED) }
    }

    fun declineInvite(friendId: String) {
        _pendingInvites.update { it.filter { f -> f.id != friendId } }
    }

    fun removeFriend(friendId: String) {
        _friends.update { it.filter { f -> f.id != friendId } }
    }

    fun sendInvite(username: String): Boolean {
        // In a real app this would call an API.
        // Here we simulate a successful send if username is non-blank.
        return username.isNotBlank()
    }

    fun generateInviteLink(userId: String): String =
        "https://weatherplan.app/invite/$userId"

    private fun demoFriends() = listOf(
        Friend("sara",   "Sara B.",     "@sara_b",    0xFF2DC98A, true,  VoteStatus.YES),
        Friend("karim",  "Karim O.",    "@karim_o",   0xFF9B59B6, true,  VoteStatus.YES),
        Friend("lina",   "Lina T.",     "@lina_t",    0xFFE056A0, false, VoteStatus.MAYBE),
        Friend("med",    "Mohamed K.",  "@med_k",     0xFFF5A623, false, VoteStatus.PENDING),
    )
}
