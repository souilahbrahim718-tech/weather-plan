package com.weatherplan.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.weatherplan.app.data.model.PlaceSuggestion
import com.weatherplan.app.data.model.WeatherData
import com.weatherplan.app.ui.theme.*

// ─────────────────────────────────────────────────────────────────────────────
// Avatar
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun Avatar(
    letter: String,
    color: Long,
    size: Dp = 40.dp,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(color))
    ) {
        Text(
            text  = letter,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize   = (size.value * 0.4f).sp
        )
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Weather summary card (shown in header)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun WeatherHeaderBanner(
    weather: WeatherData,
    modifier: Modifier = Modifier
) {
    Surface(
        shape  = RoundedCornerShape(16.dp),
        color  = Color.White.copy(alpha = 0.18f),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Text(text = weatherEmoji(weather.cloudCoverage), fontSize = 36.sp)
            Spacer(Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    "${weather.temperature.toInt()}°C",
                    style = MaterialTheme.typography.headlineMedium,
                    color = Color.White
                )
                Text(
                    weather.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.85f)
                )
                if (weather.cityName.isNotBlank()) {
                    Text(
                        "📍 ${weather.cityName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
            // Cloud % badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color.White.copy(alpha = 0.2f))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text("Cloud", color = Color.White.copy(alpha = 0.75f),
                     style = MaterialTheme.typography.labelSmall)
                Text("${weather.cloudCoverage}%",
                     color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Place suggestion card (used in Chat + on Map vote sheet)
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun PlaceSuggestionCard(
    place: PlaceSuggestion,
    currentUserId: String,
    onVoteYes: () -> Unit,
    onVoteNo:  () -> Unit,
    modifier: Modifier = Modifier
) {
    val userVote = place.votes[currentUserId]

    Surface(
        shape  = RoundedCornerShape(14.dp),
        color  = SkyBlueLight,
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, SkyBlue.copy(alpha = 0.3f), RoundedCornerShape(14.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("📍", fontSize = 22.sp)
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text(place.name,
                         style = MaterialTheme.typography.titleMedium,
                         color = TextPrimary)
                    if (place.address.isNotBlank())
                        Text(place.address,
                             style = MaterialTheme.typography.labelMedium,
                             color = TextMuted)
                }
                WeatherSuitabilityBadge(place.weatherSuitability.emoji + " " + place.weatherSuitability.label)
            }

            Spacer(Modifier.height(10.dp))

            // Vote summary
            Text(
                "${place.yesCount} ✅  ${place.noCount} ❌  of ${place.totalVotes} votes",
                style = MaterialTheme.typography.labelMedium,
                color = TextMuted
            )

            Spacer(Modifier.height(8.dp))

            // Vote buttons
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick  = onVoteYes,
                    colors   = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (userVote == true) GreenGoLight else Color.Transparent,
                        contentColor   = if (userVote == true) GreenGo else TextMuted
                    ),
                    border   = androidx.compose.foundation.BorderStroke(
                        1.dp, if (userVote == true) GreenGo else Border
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text("✓ Let's go", style = MaterialTheme.typography.labelLarge) }

                OutlinedButton(
                    onClick  = onVoteNo,
                    colors   = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (userVote == false) RedNoLight else Color.Transparent,
                        contentColor   = if (userVote == false) RedNo else TextMuted
                    ),
                    border   = androidx.compose.foundation.BorderStroke(
                        1.dp, if (userVote == false) RedNo else Border
                    ),
                    modifier = Modifier.weight(1f)
                ) { Text("✗ Pass", style = MaterialTheme.typography.labelLarge) }
            }
        }
    }
}

// ─────────────────────────────────────────────────────────────────────────────
// Small badges
// ─────────────────────────────────────────────────────────────────────────────

@Composable
fun WeatherSuitabilityBadge(label: String, modifier: Modifier = Modifier) {
    Text(
        text     = label,
        style    = MaterialTheme.typography.labelSmall,
        color    = Color(0xFF0A7A50),
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(GreenGoLight)
            .padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
fun OnlineDot(isOnline: Boolean, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(9.dp)
            .clip(CircleShape)
            .background(if (isOnline) GreenGo else Color(0xFFBDBDBD))
    )
}

@Composable
fun GoOutScoreChip(score: Int, modifier: Modifier = Modifier) {
    val (bg, fg) = when {
        score >= 75 -> GreenGoLight to Color(0xFF0A7A50)
        score >= 50 -> AmberMaybeLight to Color(0xFFA06010)
        else        -> RedNoLight to RedNo
    }
    Text(
        text  = "${score}% go-out",
        style = MaterialTheme.typography.labelMedium,
        color = fg,
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(bg)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    )
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

fun weatherEmoji(cloudCoverage: Int): String = when {
    cloudCoverage < 20 -> "☀️"
    cloudCoverage < 50 -> "⛅"
    cloudCoverage < 75 -> "🌥️"
    else               -> "☁️"
}

fun Long.toAvatarColor(): Color = Color(this)
